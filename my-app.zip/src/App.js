import Menubar from "./component/sidebar/Menubar";
import Banner from "./component/Banner/banner";
import Home from "./component/HomeContent/home";
import './App.css';
import 'antd/dist/antd.css';

function App() {
  return (
    <div className="App">
    <Menubar/>
    <Banner/>
    <Home/>
    </div>
  );
}

export default App;
