/* eslint-disable no-unused-vars */
import React from "react";
import { Input } from "antd";
import { BellOutlined, HistoryOutlined } from "@ant-design/icons";
// import Typical from "react-typical";
import styles from "../../asset/HomeContant/index.module.scss";

function Home() {


  

  return (
    <>
      <div className={styles.home}>
        <div className={styles.home_left}>
          <div className={styles.left_header}>
            <div className={styles.searchbar}>
              <label className={styles.search_state}>
                Search your district or state
              </label>
              <div className={styles.line}></div>
              <div className={styles.search_wrapper}>
                <Input type="text" />
                {/* <Typical
                  steps={["Hello", 1000, "Hello world!", 500]}
                  loop={Infinity}
                  wrapper="p"
                /> */}
              </div>
              <div className={styles.actions_panel}>
                <div className={styles.action}>
                  <h5>01 Nov, 11:22 AM IST</h5>
                  <div className={styles.bell_icon}>
                    <BellOutlined />
                    <div className={styles.indicator}></div>
                  </div>
                  <div className={styles.timeline_icon}>
                    <HistoryOutlined />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.cases_card}>
            <div className={styles.card_MapSwitcher}>
              <div className={styles.card_highlight}></div>
            </div>
            <div className={styles.card_level}>
              <div className={styles.level_items}>
                <h5>Confirmed</h5>
                <h4>+ 12,907</h4>
                <h1>3,42,85,612</h1>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.home_left}></div>
      </div>
    </>
  );
}
export default Home;
